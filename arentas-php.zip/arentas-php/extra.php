<!DOCTYPE html>
<html lang="lt">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Minimal Website!</title>
    <meta name="description" content="Arentas Stonys Final Web Development project">
    
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Lato:wght@700&family=Open+Sans:ital,wght@0,300;0,400;0,600;0,700;1,700&display=swap">
    <link href="assets/fontawesome-free-5.13.1-web/css/all.css" rel="stylesheet">
    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="css/extra.css">
    
</head>
<body>
    <header>
        <div class="container">
            <h1>Welcome to Extra Content</h1>
        </div>
    </header>
    
    <div class="firstq container">
            <h3>To unlock extra CSS content you must complete a task</h3><br><h3>Find and click on Rome</h3>
    </div>
    <div class="pictures">
            <div>
                <img src="assets/athens.jpg" alt="not-athens">
                <p class="firstp">This is not a Rome man!</p>
                <p class="secondp">This is not a Rome man!</p>
            </div>
            <div>
                <img src="assets/berlin.jpg" alt="not-berlin">
                <p class="firstp">This is not a Rome man!</p>
                <p class="secondp">This is not a Rome man!</p>
            </div>
            <div>
                <img src="assets/london.jpg" alt="not-london">
                <p class="firstp">This is not a Rome man!</p>
                <p class="secondp">This is not a Rome man!</p>
            </div>
            <div>
                <img src="assets/rome.jpg" alt="not-rome">
                 <p class="firstp">This is not a Rome man!</p>
                <p class="secondp">This is not a Rome man!</p>
            </div>
            <div>
                <img src="assets/paris.jpg" alt="not-paris">
                 <p class="firstp">This is not a Rome man!</p>
                <p class="secondp">This is not a Rome man!</p>
            </div>
            <div>
                <img src="assets/madrid.jpg" alt="not-madrid">
                 <p class="firstp">This is not a Rome man!</p>
                <p class="secondp">This is not a Rome man!</p>
            </div>
    </div>
    <div class="link-to-rome">
        <a href="rome.php">Rome is Here!</a>
    </div>
    
    <footer>
        <a href="index.php"><button class="back-btn">I want to get back to Main</button></a>
    </footer>
    
    <script src="scripts/jquery.min.js"></script>
    <script src="bootstrap-4.5.0-dist/js/bootstrap.bundle.min.js"></script>
    <script src="scripts/mano.js"></script>
</body>
<html>
</html>