<?php
    require __DIR__ . '/app/app.php';
?>
<!DOCTYPE html>
<html lang="lt">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Minimal Website!</title>
    <meta name="description" content="Arentas Stonys Final Web Development project">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Lato:wght@700&family=Open+Sans:ital,wght@0,300;0,400;0,600;0,700;1,700&display=swap">
    <link href="assets/fontawesome-free-5.13.1-web/css/all.css" rel="stylesheet">
    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
    <!-- NavHeader Pradžia-->

        <div class="nav-header">
        <div class="nav-header-container grid-container container">   
            <div class="logo">
                <a href="index.php" target="_self"><img src="assets/images/logol_03.png" alt="Website Logo"></a>
            </div> 
            <!-- logotipas -->
            
            <nav class="topnav">
                        <ul class="ulas">
                            <li class="nav-item">
                                <a class="nav-link" href="#services">Services</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#story">Our Story</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#work">Work</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#work">Journal</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#contanct">Contact</a>
                            </li>
                        </ul>
            </nav>
        </div>
    </div>
<!-- mobilus Nav Headeris-->
<div class="mobile-container container nav-header-container">

            <!-- Top Navigation Menu -->
            <div class="topnav">
              <a href="#home" class="active"><img src="assets/images/logol_03.png" alt="Website Logo"></a>
              <div id="myLinks">
                <a href="#services">Services</a>
                <a href="#story">Our Story</a>
                <a href="#work">Work</a>
                <a href="#work">Journal</a>
                <a href="#contact">Contact</a>
              </div>
              <a href="javascript:void(0);" class="icon" onclick="myFunction()">
                <i class="fa fa-bars"></i>
              </a>
            </div>
</div>
        
                
        
</header> <!-- NavHeader pabaiga-->
<main>
    <div class="main"> <!-- Main pradžia -->
        <div class="main-container flex"> <!--Pirma sekcija-->
            <h1>Minima Clean &amp; Minimal Template</h1>
            <h3>excepteur occaecat cupitadat non proident</h3>
            <a href="extra.php"><button class="button" type="button">START HERE <i class="fas fa-long-arrow-alt-right"></i></button></a>   
        </div> <!-- Pirmos Sekcijos Pabaiga-->
        <div id="services" class="main-second-container"> <!--Antra  sekcija-->
            <div class="row">
                    <div class="col1">
                        <img src="assets/images/cup_icon.png">
                        <h3><B>DUIS AUTE IRURE</B></h3>
                        <P>Excepeteur sint occaecat cupi datat non proident, sunt in culpa qui officia dose runtom mollit anim id est laborum.</P>
                    </div>
                    <div class="col2">
                        <img src="assets/images/odometer_Icon.png">
                        <h3><B>DUIS AUTE IRURE</B></h3>
                        <P>Excepeteur sint occaecat cupi datat non proident, sunt in culpa qui officia dose runtom mollit anim id est laborum.</P>
                    </div>
                    <div class="col3">
                        <img src="assets/images/camera_icon.png">
                        <h3><B>DUIS AUTE IRURE</B></h3>
                        <P>Excepeteur sint occaecat cupi datat non proident, sunt in culpa qui officia dose runtom mollit anim id est laborum.</P>
                    </div>
            </div>
        <hr class="hr">
    </div><!--Antros sekcijos pabaiga-->
        <div class="main-third-container"><!--Trečia  sekcija-->
            <h2><b>SUNT IN CULPA QUI OFFCIA DESERUNT MOLLIT</b></h2>
            <p>Excepeteur sint occaecat cupi datat non proident, sunt in culpa qui officia dose runtom mollit anim id est laborum.</p>
            <div class="flex test">
                <div class="embed-responsive embed-responsive-4by3">
                    <iframe class="video" src="https://www.youtube.com/embed/Xsi72MpIclc" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" ></iframe>
                </div>
            </div>
            <hr class="hr2">
        </div><!--Trečios  sekcijos pabaiga-->
        <div id="work" class="main-fourth-container"><!--Ketvirta  sekcija-->
            <div class="row1">
                <h2>RECENT WORK</h2>
            </div>
            <div class="row2">
                <div class="card1">
                    <div id="wrapper">
                        <a href="#" target="_self"><img src="assets/images/Icon_Box.png" class="hover"></a>
                        <p class="TxtOnTop"><br>Brand Project   <i class="fas fa-long-arrow-alt-right"></i></p>
                    </div>
                </div>
                <div class="card2">
                    <div id="wrapper">
                        <a href="#" target="_self"><img src="assets/images/Icon_Box.png" class="hover"></a>
                        <p class="TxtOnTop"><br>Brand Project   <i class="fas fa-long-arrow-alt-right"></i>
                    </div>
                </div>
                <div class="card3">
                    <div id="wrapper">
                    <a href="#" target="_self"><img src="assets/images/Icon_Box.png" class="hover"></a>
                    <p class="TxtOnTop"><br>Brand Project   <i class="fas fa-long-arrow-alt-right"></i>
                    </div>
                </div>
                <div class="card4">
                    <div id="wrapper">
                    <a href="#" target="_self"><img src="assets/images/Icon_Box.png" class="hover"></a>
                    <p class="TxtOnTop"><br>Brand Project   <i class="fas fa-long-arrow-alt-right"></i>
                    </div>
                </div>
            </div>
        </div> <!--Ketvirtos sekcijos  pabaiga-->
        <div id="story" class="main-fifth-container"><!--Penkta sekcija-->
            <h2>JOIN OUR SUBSCRIBERS.</h2>
            <p>10000 sint ocaecat cupitadat non proident sunt in culpa qui officia.</p>
            <button class="button1" type="button"><b>CLICK HERE TO SUBSCRIBE</b></button>
        </div><!--Penktos sekcijos  pabaiga-->
        <div class="container contact-form">
            <div class="form-heading">
                <h2>Get in touch</h2>
                <p>Lorem ipsum dolor sit amet, consecutuer adspiscing elit, sed diam nonumy nibh.</p>
            </div>
            <div id="contanct" class="section-content">
                <form class="contact-form" action="index.php" method="post">
                        <input type="text" name="name" placeholder="Your Name*">
                        <input type="email" name="email" placeholder="Your Email*">
                        <input type="tel" name="tel" placeholder="Your mobile Number*">
                        <textarea name="message" rows="8" placeholder="Your Message" required></textarea>
                        <input type="submit" class="btn btn-form" name="submit">
                </form>
            </div>
        </div>
        <div class="main-sixt-container"><!--Šešta sekcija-->
            <div class="row-sixt">
                <a href="https://www.facebook.com/" target="_blank"><i class="fab fa-facebook-f"></i></a> 
                <a href="https://twitter.com" target="_blank"><i class="fab fa-twitter"></i></a>
                <a href="https://fiba3x3.com/" target="_blank"><i class="fas fa-basketball-ball"></i></a>
                <a href="https://google.com" target="_blank"><i class="fab fa-google"></i></a>
            </div>
        </div><!--Šeštos sekcijos  pabaiga-->
    </div>
</main>
<footer> <!-- Footeris-->
    <div class="footer">
        <br><br>
        <div class="footer-row">
            <ul class="f1">
                <li><h4>Location</h4></li>
                <li><br></li>
                <li><p>1401 South Grand Avenue Los Angeles, CA 90015</p></li>
                <li><a href="tel:+3706123456">(213) 748-2411</a></li>
                <li><a href="https://goo.gl/maps/9RginLNZEnuBMiBP7" target="_blank">see in the map <i class="fas fa-long-arrow-alt-right"></i></a></li>
            </ul>
            <ul class="f1">
                <li><h4>Company</h4></li>
                <li><br></li>
                <li><p>Our Story</p></li>
                <li><p>Mission</p></li>
                <li><p>Journal</p></li>
                <li><p>Careers</p></li>
            </ul>
            <ul class="f1">
                <li><h4>Support</h4></li>
                <li><br></li>
                <li><p>FAQ</p></li>
                <li><p>Contact us</p></li>
                <li><p>Policies</p></li>
            </ul>
            <ul class="f1">
                <li><h4>Minima.</h4></li>
                <li><br></li>
                <li><p>This project was made for training purposes by<a href="author.php" target="_blank"> Arentas Stonys.</a></p></li>
                <li>Template made by <a href="https://pixelhint.com" target="_blank">pixelhint.com</a></li>
            </ul>
        </div>
    </div>
</footer>
    <script src="scripts/jquery.min.js"></script>
    <script src="bootstrap-4.5.0-dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        function myFunction() {
          var x = document.getElementById("myLinks");
          if (x.style.display === "block") {
            x.style.display = "none";
          } else {
            x.style.display = "block";
          }
        }
</script>
    <script src="scripts/mano.js"></script>
</body>
</html>
