<!DOCTYPE html>
<html lang="lt">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Minimal Website!</title>
    <meta name="description" content="Arentas Stonys Final Web Development project">
    
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Lato:wght@700&family=Open+Sans:ital,wght@0,300;0,400;0,600;0,700;1,700&display=swap">
    <link href="assets/fontawesome-free-5.13.1-web/css/all.css" rel="stylesheet">
    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="css/rome.css">
    
</head>
<body>
    <header>
        <div class="container">
            <h1>You managed to find Rome!</h1>
        </div>
    </header>
    
<!--    firewoorks starts here-->
    <div class="pyro">
        <div class="before"></div>
        <div class="after"></div>
    </div>
<!--    fireworks ends here-->
    
    
    <div class="btn">
        <a href="index.php"><button class="btn-two">I want to get back to Main</button></a>
    </div>
<!--
    <footer>
        <a href="index.php"><button class="btn-two">I want to get back to Main</button></a>
    </footer>
-->
    
    <script src="scripts/jquery.min.js"></script>
    <script src="bootstrap-4.5.0-dist/js/bootstrap.bundle.min.js"></script>
    <script src="scripts/mano.js"></script>
</body>
<html>
</html>