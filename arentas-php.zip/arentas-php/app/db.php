<?php 
    define ("DB_SERVER", "localhost");
    define ("DB_USER", "root");
    define ("DB_PASSWORD", "");
    define ("DB_NAME", "projektas");

    if(isset($_POST['submit']) && !empty($vardas) && !empty($email) && !empty($message)) {
        
    $mysqli = new mysqli(DB_SERVER, DB_USER, DB_PASSWORD, DB_NAME);
    if($mysqli->connect_error) {
        echo "Atsiprašome, bet svetainė susidūrė su problema.\n";
        echo 'Klaida: ' . $mysqli->connect_error . '\n';
        exit();
    }
    mysqli_query($mysqli, "INSERT INTO zmones (vardas, email, zinute, telno)
    VALUES('$vardas', '$email', '$message' ,'$tel')");
        
}